package com.google.zxing.listener;

/**
 * Created by lockyluo on 2017/8/18.
 */

public interface ResultListener {
    void onResult(String result);
}
