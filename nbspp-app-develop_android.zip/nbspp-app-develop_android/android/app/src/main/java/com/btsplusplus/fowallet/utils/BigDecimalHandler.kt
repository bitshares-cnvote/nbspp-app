package com.btsplusplus.fowallet.utils

class BigDecimalHandler(var roundingMode: Int, var scale: Int)