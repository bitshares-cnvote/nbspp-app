package bitshares

import org.json.JSONObject

class MySecurityFileMgr {

    companion object {
        fun loadDicSecFile(fullname: String): JSONObject? {
            return null
        }

        fun saveSecFile(obj: Any, fullname: String): Boolean {
            return false
        }
    }
}